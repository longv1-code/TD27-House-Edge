# House Edge team entry (main round): ensemble of two models

- Environment: python image, numpy==2.5.4 and scipy==1.18.1 (requirements.txt). CPU only, no network, deterministic (no randomness).
- Recreate: python predict_blend.py --data /data --out /output/submission.csv
  (runs predict.py --predict for the plus model into a temp file, runs the generative model, averages 50/50, writes the CSV).
- Plus model: checkpoint.json + plus_model/ (unchanged; see its own description: lag-pattern discovery for win and payout size,
  joint lag prior, HMM with episode factor; fitted on train + validation targets).
- Generative switching model (gen.py, gen_data.py, gen_params.npz): per machine and lag pair, a 4-state filter over
  (which XOR cell of win(t-a), win(t-b) is the high-loss cell, sign linking a big win at lag a to the 1x-share state),
  both allowed to flip; emissions P(loss | type, cell, size state, signal), P(1x | win, type, size state), big-win size mix per type.
  Bayesian averaging over all 28 lag pairs (learned pair prior) and two switch rates, then time-decayed episode and machine
  logit offsets estimated from residuals. Parameters fitted by EM on train + validation histories (gen_fit.py); no
  validation targets are used by this model. Only ticks before each cutoff are used.
- Validation (episode-out-of-fold for the plus model; generative model fitted on train only): plus 58.38, generative 58.28,
  50/50 ensemble 58.67 points / 60.
- The generative part runs entirely in float64 (1-ulp log/exp noise changes its output by ~1e-14).
