"""Honest dev run: fit on <data>/train only, score <data>/validation (never used for fitting).
Usage: python dev.py --data public [--max-points 60]"""
import argparse, time
import numpy as np
import he

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="public")
ap.add_argument("--max-points", type=float, default=60.0)
a = ap.parse_args()
t0 = time.time()
tr, va = he.Split(f"{a.data}/train"), he.Split(f"{a.data}/validation")
prior = he.global_prior([tr])
he.PAIR_LOGPRIOR = he.learn_pair_prior([tr])
he.SIZE_MIX = he.learn_size_mix([tr])
print('pair prior top:', [he.PAIRS[j] for j in np.argsort(-he.PAIR_LOGPRIOR)[:4]], 'size mix:', he.SIZE_MIX.round(3).tolist(), flush=True)
Ctr, Cva = he.Corpus([tr], prior), he.Corpus([va], prior)
print(f"features ready {time.time()-t0:.0f}s  train ex={len(Ctr.hX)} F={Ctr.hX.shape[1]}", flush=True)
Mod = he.fit_v1(Ctr, np.ones(Ctr.M, bool), he.V1_CFG, log=lambda s: print(s, time.time() - t0, flush=True))
print(f"reference pooled baseline would score {a.max_points/2:.1f}")
for name, gated in (("mlp", False), ("gated", True)):
    r = he.contest(he.predict_v1(Mod, Cva.qX, gated), Cva, a.max_points)
    print(f"{name:6s} points={r['points']:.2f}  R={r['R']:.3f}  {r['by_cond']}")
print(f"total {time.time()-t0:.0f}s")
