# House Edge entry (main round, solution s2)

- Environment: python image, Python 3.12+ (tested 3.12.3), numpy==2.5.4 (see requirements.txt). No network, no other packages.
- Recreate: python predict.py --data /data --out /output/submission.csv --solution s2
- The command loads model.npz (trained weights, seeds fixed in the config stored inside it) and runs a deterministic forward pass on /data/test. Runtime is under 1 minute on 2 cores, under 2 GiB RAM.
- Training (not needed for reproduction): python fit_final.py --data public --ckpt model.npz (train+validation, 4-fold out-of-fold gate fit, seeds in he.DEFAULT_CFG). Training code is he.py plus fit_final.py in the project folder.
- Solutions: s1 tuned decayed frequency; s2 5-seed MLP ensemble; s3 5-seed MLP ensemble with neighbor features; s4 per-machine adaptation of s2; s5 regime-gated blend of s1-s4.
- Features only read ticks strictly before the target tick. No outside data.
