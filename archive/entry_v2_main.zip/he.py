"""House Edge toolkit (numpy only). Features use ticks strictly below the target tick."""
import csv
import json
from pathlib import Path

import numpy as np

PAY = (0, 1, 2, 5, 20)
PIDX = {p: i for i, p in enumerate(PAY)}
TYPES = ("steady", "balanced", "jackpot")
PCOLS = ("p_0", "p_1", "p_2", "p_5", "p_20")
T = 260
NL = 8
WIN = (8, 16, 32, 64, 128)
NWIN = (8, 32, 128)
TMIN = 24
LAYOUT = {}
FEAT_DTYPE = np.float32  # predict.py sets float64 so platform-level rounding noise cannot flip float32 bits


def _rows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


# ----------------------------------------------------------------------------- data
class Split:
    def __init__(self, d):
        d = Path(d)
        Q, H = _rows(d / "queries.csv"), _rows(d / "history.csv")
        self.qid = [q["query_id"] for q in Q]
        M = self.M = len(Q)
        eps = {}
        self.ep = np.array([eps.setdefault(q["episode_id"], len(eps)) for q in Q])
        self.E = len(eps)
        self.mtype = np.array([TYPES.index(q["machine_type"]) for q in Q])
        self.sig = np.array([int(q["signal"]) + 1 for q in Q])
        self.cut = np.array([int(q["cutoff"]) for q in Q])
        mid = {(q["episode_id"], q["machine_id"]): i for i, q in enumerate(Q)}
        C = -np.ones((M, T), np.int8)
        for r in H:
            i = mid.get((r["episode_id"], r["machine_id"]))
            if i is not None:
                C[i, int(r["tick"])] = PIDX[int(r["payout"])]
        C[np.arange(T)[None, :] >= self.cut[:, None]] = -1  # nothing at/after cutoff
        self.C = C
        pos = {q: i for i, q in enumerate(self.qid)}
        self.out = self.tgt = self.ref = self.cond = None
        if (d / "labels.csv").exists():
            self.out = np.zeros(M, int)
            for r in _rows(d / "labels.csv"):
                self.out[pos[r["query_id"]]] = PIDX[int(r["outcome"])]
        if (d / "targets.csv").exists():
            self.tgt = np.zeros((M, 5))
            self.out = np.zeros(M, int)
            for r in _rows(d / "targets.csv"):
                i = pos[r["query_id"]]
                self.tgt[i] = [float(r[c]) for c in PCOLS]
                self.out[i] = PIDX[int(r["outcome"])]
        if (d / "reference.csv").exists():
            self.ref = np.zeros((M, 5))
            for r in _rows(d / "reference.csv"):
                self.ref[pos[r["query_id"]]] = [float(r[c]) for c in PCOLS]
        if (d / "conditions.csv").exists():
            self.cond = np.empty(M, object)
            for r in _rows(d / "conditions.csv"):
                self.cond[pos[r["query_id"]]] = r["condition"]
        self._tensors()

    def _tensors(self):
        M = self.M
        OH = np.zeros((M, T, 5), np.float32)
        mi, ti = np.nonzero(self.C >= 0)
        OH[mi, ti, self.C[mi, ti]] = 1
        self.OH = OH
        self.CS = np.zeros((M, T + 1, 5), np.float32)
        self.CS[:, 1:] = np.cumsum(OH, 1)
        EOH = np.zeros((self.E, T, 5), np.float32)
        np.add.at(EOH, self.ep, OH)
        self.NOH = EOH[self.ep] - OH
        ECS = np.zeros((self.E, T + 1, 5), np.float32)
        ECS[:, 1:] = np.cumsum(EOH, 1)
        self.NCS = ECS[self.ep] - self.CS
        self.esz = np.bincount(self.ep)[self.ep].astype(np.float32)
        # per-machine lag tables: LT[k-1][m, t, prev_state(loss/win), class_now] = #pairs (s-k, s) with s < t
        self.LT = []
        C = self.C.astype(np.int16)
        for k in range(1, NL + 1):
            ind = np.zeros((M, T + 1, 2, 5), np.float32)
            cur, prv = C[:, k:], C[:, :-k]
            ok = (cur >= 0) & (prv >= 0)
            m_, s_ = np.nonzero(ok)
            ind[m_, s_ + k + 1, (prv[m_, s_] > 0).astype(int), cur[m_, s_]] = 1  # counted for t > s
            self.LT.append(np.cumsum(ind, 1))


PAIRS = [(a, b) for a in range(1, NL + 1) for b in range(a + 1, NL + 1)]
PHL = (16.0, 48.0, 0.0)  # half-lives for pair cell rates; 0 = no decay
PTOP = 3


def _pair_sums(S, a, b, hl):
    """D[m, t, j] = (decayed) sums over u < t of [eq_u, eq_u*loss_u, neq_u, neq_u*loss_u]; eq_u means
    win(u-a) == win(u-b), all three of u, u-a, u-b observed."""
    C = S.C
    Mn = C.shape[0]
    x = np.zeros((Mn, T, 4), np.float64)
    u = np.arange(b, T)
    cu, ca, cb = C[:, u], C[:, u - a], C[:, u - b]
    ok = (cu >= 0) & (ca >= 0) & (cb >= 0)
    eq = ok & ((ca > 0) == (cb > 0))
    ne = ok & ~eq
    loss = cu == 0
    x[:, u, 0], x[:, u, 1], x[:, u, 2], x[:, u, 3] = eq, eq & loss, ne, ne & loss
    D = np.zeros((Mn, T + 1, 4), np.float64)
    if hl <= 0:
        D[:, 1:] = np.cumsum(x, 1)
    else:
        lam = 2.0 ** (-1.0 / hl)
        for t in range(T):
            D[:, t + 1] = lam * D[:, t] + x[:, t]
    return D


def pairfeats(S, mi, ti):
    """Per-machine XOR-pair features at (mi, ti), from ticks < ti only. Top-PTOP pairs by strength."""
    n = len(mi)
    P = len(PAIRS)
    cur = np.zeros((n, P, len(PHL)))
    eff = np.zeros((n, P, len(PHL)))
    z = np.zeros((n, P, len(PHL)))
    cell = np.zeros((n, P))
    sup = np.zeros((n, P))
    for j, (a, b) in enumerate(PAIRS):
        ca = S.C[mi, np.maximum(ti - a, 0)]
        cb = S.C[mi, np.maximum(ti - b, 0)]
        known = (ti - b >= 0) & (ca >= 0) & (cb >= 0)
        is_eq = (ca > 0) == (cb > 0)
        cell[:, j] = np.where(known, np.where(is_eq, 1.0, -1.0), 0.0)
        for h, hl in enumerate(PHL):
            D = _pair_sums(S, a, b, hl)[mi, ti]
            ne_, le_, nn_, ln_ = D[:, 0], D[:, 1], D[:, 2], D[:, 3]
            base = (le_ + ln_ + 1.0) / (ne_ + nn_ + 2.0)
            re = (le_ + 2 * base) / (ne_ + 2)
            rn = (ln_ + 2 * base) / (nn_ + 2)
            eff[:, j, h] = re - rn
            cur[:, j, h] = np.where(cell[:, j] > 0, re, np.where(cell[:, j] < 0, rn, base))
            v = base * (1 - base) * (1.0 / (ne_ + 1) + 1.0 / (nn_ + 1))
            z[:, j, h] = (re - rn) / np.sqrt(v + 1e-9)
            if hl <= 0:
                sup[:, j] = (ne_ + nn_) / 100.0
    strength = np.max(np.abs(z[:, :, [1, 2]]), 2)
    order = np.argsort(-strength, 1, kind="stable")[:, :PTOP]
    ar = np.arange(n)[:, None]
    out = [cur[ar, order].reshape(n, -1), eff[ar, order].reshape(n, -1), np.tanh(z[ar, order] / 4).reshape(n, -1),
           cell[ar, order], sup[ar, order], np.sort(strength, 1)[:, ::-1][:, :PTOP] / 10.0]
    return np.concatenate(out, 1)



def flipgrid(S, hls=(8.0, 16.0)):
    """Per (machine, tick) flip score from ticks < t: sum_pairs w*eff_recent*eff_long / sum w, w = |z_long|.
    Negative = recent pair effects contradict long-run ones. Returns own and same-episode-neighbour means."""
    Mn = S.C.shape[0]
    num = np.zeros((len(hls), Mn, T + 1))
    den = np.zeros((Mn, T + 1)) + 1e-6
    for (a, b) in PAIRS:
        L = _pair_sums(S, a, b, 0.0)
        ne_, le_, nn_, ln_ = L[..., 0], L[..., 1], L[..., 2], L[..., 3]
        base = (le_ + ln_ + 1.0) / (ne_ + nn_ + 2.0)
        el = (le_ + 2 * base) / (ne_ + 2) - (ln_ + 2 * base) / (nn_ + 2)
        w = np.abs(el) / np.sqrt(base * (1 - base) * (1.0 / (ne_ + 1) + 1.0 / (nn_ + 1)) + 1e-9)
        den += w
        for h, hl in enumerate(hls):
            R = _pair_sums(S, a, b, hl)
            ne2, le2, nn2, ln2 = R[..., 0], R[..., 1], R[..., 2], R[..., 3]
            b2 = (le2 + ln2 + 1.0) / (ne2 + nn2 + 2.0)
            er = (le2 + 2 * b2) / (ne2 + 2) - (ln2 + 2 * b2) / (nn2 + 2)
            num[h] += w * er * np.sign(el)
    own = num / den[None]
    E = np.zeros((len(hls), S.E, T + 1))
    for h in range(len(hls)):
        np.add.at(E[h], S.ep, own[h])
    nb = (E[:, S.ep] - own) / np.maximum(S.esz - 1, 1)[None, :, None]
    return own, nb


HMM_EPS = (0.01, 0.04)
HMM_TOP = 2


def _hmm_pair(C, a, b, eps):
    """Two-state switching filter for pair (a,b), all machines at once. Returns grids (M, T+1) holding, for tick t,
    values computed from ticks < t: predicted P(loss), state posterior, cumulative log-lik gain, flip activity."""
    Mn = C.shape[0]
    pi = np.full(Mn, 0.02)
    nh = np.zeros(Mn); kh = np.zeros(Mn); nl = np.zeros(Mn); kl = np.zeros(Mn)
    nb_ = np.zeros(Mn); kb_ = np.zeros(Mn)
    LL = np.zeros(Mn)
    Lg = np.zeros((Mn, T + 1)); Pg = np.zeros((Mn, T + 1)); LLg = np.zeros((Mn, T + 1))
    for t in range(T + 1):
        h = (kh + 2.8) / (nh + 4.0)
        l = (kl + 1.2) / (nl + 4.0)
        if t >= b and t < T:
            ca, cb = C[:, t - a], C[:, t - b]
            known = (ca >= 0) & (cb >= 0)
            eq = (ca > 0) == (cb > 0)
        else:
            known = np.zeros(Mn, bool); eq = np.zeros(Mn, bool)
        r0 = np.where(known, np.where(eq, h, l), 0.5 * (h + l))
        r1 = np.where(known, np.where(eq, l, h), 0.5 * (h + l))
        Lg[:, t] = pi * r1 + (1 - pi) * r0
        Pg[:, t] = pi
        LLg[:, t] = LL
        if t >= T:
            break
        y = C[:, t]
        obs = (y >= 0) & known
        loss = (y == 0)
        l1 = np.where(loss, r1, 1 - r1); l0 = np.where(loss, r0, 1 - r0)
        mix = pi * l1 + (1 - pi) * l0
        base = (kb_ + 1.0) / (nb_ + 2.0)
        lb = np.where(loss, base, 1 - base)
        LL = LL + np.where(obs, np.log(mix + 1e-12) - np.log(lb + 1e-12), 0.0)
        post = np.where(obs, pi * l1 / (mix + 1e-12), pi)
        wh = np.where(eq, 1 - post, post) * obs
        wl = np.where(eq, post, 1 - post) * obs
        nh += wh; kh += wh * loss; nl += wl; kl += wl * loss
        nb_ += (y >= 0); kb_ += (y == 0)
        pi = post * (1 - eps) + (1 - post) * eps
    return Lg, Pg, LLg


def hmmgrid(S):
    """Top-HMM_TOP pairs (by causal log-lik gain) per (machine, tick) for each eps. Grids (k, M, T+1)."""
    C = S.C
    Mn = C.shape[0]
    out = []
    for eps in HMM_EPS:
        bestLL = np.full((HMM_TOP, Mn, T + 1), -1e18)
        bestL = np.zeros((HMM_TOP, Mn, T + 1)); bestP = np.zeros((HMM_TOP, Mn, T + 1)); bestF = np.zeros((HMM_TOP, Mn, T + 1))
        for (a, b) in PAIRS:
            Lg, Pg, LLg = _hmm_pair(C, a, b, eps)
            Fg = np.zeros_like(Pg)
            Fg[:, 24:] = np.abs(Pg[:, 24:] - Pg[:, :-24])
            # insert into sorted top list
            for k in range(HMM_TOP):
                better = LLg > bestLL[k]
                for arr, new in ((bestLL, LLg), (bestL, Lg), (bestP, Pg), (bestF, Fg)):
                    old = arr[k].copy()
                    arr[k] = np.where(better, new, arr[k])
                    if arr is bestLL:
                        LLg = np.where(better, old, LLg)
                    elif arr is bestL:
                        Lg = np.where(better, old, Lg)
                    elif arr is bestP:
                        Pg = np.where(better, old, Pg)
                    else:
                        Fg = np.where(better, old, Fg)
        E = np.zeros((S.E, T + 1))
        np.add.at(E, S.ep, bestF[0])
        nbF = (E[S.ep] - bestF[0]) / np.maximum(S.esz - 1, 1)[:, None]
        out.append((bestL, bestP, bestLL, bestF, nbF))
    return out


def hmmfeats(S, mi, ti):
    if not hasattr(S, "_hmm"):
        S._hmm = hmmgrid(S)
    cols = []
    tt = np.maximum(ti, 1).astype(np.float64)
    for bestL, bestP, bestLL, bestF, nbF in S._hmm:
        for k in range(HMM_TOP):
            cols += [bestL[k][mi, ti], np.minimum(bestP[k][mi, ti], 1 - bestP[k][mi, ti]), np.tanh(bestLL[k][mi, ti] / 20.0),
                     bestLL[k][mi, ti] / tt, bestF[k][mi, ti]]
        cols.append(nbF[mi, ti])
    return np.stack(cols, 1)


def feats(S, mi, ti, prior):
    """Feature rows for (machine, tick) pairs. Only ticks < ti are read."""
    f, pos = [], [0]
    first = not LAYOUT

    def add(name, a):
        a = np.asarray(a, FEAT_DTYPE)
        if a.ndim == 1:
            a = a[:, None]
        f.append(a)
        if first:
            LAYOUT[name] = slice(pos[0], pos[0] + a.shape[1])
        pos[0] += a.shape[1]

    mt, sg = S.mtype[mi], S.sig[mi]
    add("type", np.eye(3)[mt])
    add("sig", np.eye(3)[sg])
    add("typesig", np.eye(9)[mt * 3 + sg])
    add("t", ti / 256.0)
    lagoh, W, L, nfrac = [], [], [], []
    for k in range(1, NL + 1):
        tk = np.maximum(ti - k, 0)
        ok = (ti - k >= 0)[:, None]
        v = S.OH[mi, tk] * ok
        nv = S.NOH[mi, tk] * ok
        lagoh.append(v)
        W.append(v[:, 1:].sum(1))
        L.append(v[:, 0])
        nfrac.append((nv[:, 1:].sum(1) + 0.8) / (nv.sum(1) + 2.0))
    add("lagoh", np.concatenate(lagoh, 1))
    wl = np.concatenate([np.stack(W, 1), np.stack(L, 1)], 1)
    add("wl", wl)
    add("wl_t", np.concatenate([wl * (mt == j)[:, None] for j in range(3)], 1))
    add("wl_s", np.concatenate([wl * (sg == j)[:, None] for j in range(3)], 1))
    add("nfrac", np.stack(nfrac, 1))
    for w in WIN:
        lo = np.maximum(ti - w, 0)
        cnt = S.CS[mi, ti] - S.CS[mi, lo]
        n = cnt.sum(1)
        add(f"rate{w}", (cnt + 4 * prior) / (n + 4)[:, None])
        add(f"cov{w}", n / np.maximum(ti - lo, 1))
    for w in NWIN:
        lo = np.maximum(ti - w, 0)
        cnt = S.NCS[mi, ti] - S.NCS[mi, lo]
        n = cnt.sum(1)
        add(f"nrate{w}", (cnt + 4 * prior) / (n + 4)[:, None])
        add(f"ncov{w}", n / (np.maximum(ti - lo, 1) * (S.esz[mi] - 1)))

    def wr(CS, a, b):
        lo, hi = np.maximum(ti - b, 0), np.maximum(ti - a, 0)
        cnt = CS[mi, hi] - CS[mi, lo]
        return (cnt[:, 1:].sum(1) + 0.8) / (cnt.sum(1) + 2.0)

    mr = (S.CS[mi, ti] + 4 * prior) / (S.CS[mi, ti].sum(1) + 4)[:, None]
    dist, lift, sup = [], [], []
    ar = np.arange(len(mi))
    for k in range(1, NL + 1):
        tab = S.LT[k - 1][mi, ti]
        pv = S.C[mi, np.maximum(ti - k, 0)]
        has = (ti - k >= 0) & (pv >= 0)
        tab_s = np.where(has[:, None], tab[ar, (pv > 0).astype(int)], tab.sum(1))
        dist.append((tab_s + 6 * mr) / (tab_s.sum(1) + 6)[:, None])
        sup.append(tab_s.sum(1) / 50.0)
        lift.append((tab[:, 1, 1:].sum(1) + 0.8) / (tab[:, 1].sum(1) + 2) - (tab[:, 0, 1:].sum(1) + 0.8) / (tab[:, 0].sum(1) + 2))
    add("mdist", np.concatenate(dist, 1))
    add("mlift", np.stack(lift, 1))
    add("msup", np.stack(sup, 1))
    d_own = wr(S.CS, 0, 32) - wr(S.CS, 32, 128)
    d_nb = wr(S.NCS, 0, 32) - wr(S.NCS, 32, 128)
    add("drift", np.stack([d_own, d_nb, np.abs(d_own), np.abs(d_nb)], 1))
    add("pairs", pairfeats(S, mi, ti))
    if not hasattr(S, "_flip"):
        S._flip = flipgrid(S)
    own, nb = S._flip
    add("flip", np.concatenate([own[:, mi, ti].T, nb[:, mi, ti].T], 1))
    add("hmm", hmmfeats(S, mi, ti))
    return np.concatenate(f, 1)


class Corpus:
    """One or more splits stacked: history examples, query rows, targets."""

    def __init__(self, splits, prior):
        self.prior = np.asarray(prior, np.float64)
        parts = dict(ep=[], mtype=[], sig=[], cut=[], OH=[], cond=[], tgt=[], ref=[], hmi=[], hti=[], hX=[], hY=[], qX=[], qY=[], qsoft=[])
        off_m, off_e = 0, 0
        for S in splits:
            m = np.arange(S.M)
            mi, ti = np.nonzero((S.C >= 0) & (np.arange(T)[None, :] >= TMIN))
            parts["hX"].append(feats(S, mi, ti, self.prior))
            parts["hY"].append(np.eye(5, dtype=np.float32)[S.C[mi, ti]])
            parts["hmi"].append(mi + off_m)
            parts["hti"].append(ti)
            parts["qX"].append(feats(S, m, S.cut, self.prior))
            if S.tgt is not None:
                parts["qY"].append(S.tgt)
                parts["qsoft"].append(np.ones(S.M, bool))
            elif S.out is not None:
                parts["qY"].append(np.eye(5)[S.out])
                parts["qsoft"].append(np.zeros(S.M, bool))
            else:
                parts["qY"].append(np.full((S.M, 5), np.nan))
                parts["qsoft"].append(np.zeros(S.M, bool))
            parts["ep"].append(S.ep + off_e)
            for k in ("mtype", "sig", "cut", "OH"):
                parts[k].append(getattr(S, k))
            parts["cond"].append(S.cond if S.cond is not None else np.full(S.M, "?", object))
            parts["tgt"].append(S.tgt if S.tgt is not None else np.full((S.M, 5), np.nan))
            parts["ref"].append(S.ref if S.ref is not None else np.full((S.M, 5), np.nan))
            off_m += S.M
            off_e += S.E
        for k, v in parts.items():
            setattr(self, k, np.concatenate(v))
        self.M = off_m
        self.E = off_e
        self.qid = [q for S in splits for q in S.qid]


def global_prior(splits):
    c = np.zeros(5)
    for S in splits:
        c += S.OH.sum((0, 1))
    return (c + 0.5) / (c.sum() + 2.5)


# ----------------------------------------------------------------------------- optimisers / nets
class Adam:
    def __init__(self, lr):
        self.lr, self.m, self.v, self.t = lr, {}, {}, 0

    def step(self, params, grads):
        self.t += 1
        for k in params:
            m = self.m.setdefault(k, np.zeros_like(params[k]))
            v = self.v.setdefault(k, np.zeros_like(params[k]))
            m *= 0.9
            m += 0.1 * grads[k]
            v *= 0.999
            v += 0.001 * grads[k] ** 2
            mh, vh = m / (1 - 0.9 ** self.t), v / (1 - 0.999 ** self.t)
            params[k] -= self.lr * mh / (np.sqrt(vh) + 1e-8)


class SoftmaxModel:
    def __init__(self, F=None, prior=None):
        self.p = None if F is None else {"W": np.zeros((F, 5), np.float32), "b": np.log(prior).astype(np.float32)}

    def logits(self, X):
        return X @ self.p["W"] + self.p["b"]

    def fit(self, X, Y, w, l2, iters, lr=0.05):
        opt, sw = Adam(lr), w.sum()
        for _ in range(iters):
            P = softmax(self.logits(X))
            R = (P - Y) * w[:, None]
            g = {"W": X.T @ R / sw + 2 * l2 * self.p["W"], "b": R.sum(0) / sw}
            opt.step(self.p, {k: v.astype(np.float32) for k, v in g.items()})
        return self


class MLP:
    def __init__(self, F=None, H=96, prior=None, seed=0):
        if F is not None:
            r = np.random.RandomState(seed)
            self.p = {"W1": (r.randn(F, H) * np.sqrt(2.0 / F)).astype(np.float32), "b1": np.zeros(H, np.float32),
                      "W2": (r.randn(H, 5) * 0.05).astype(np.float32), "b2": np.log(prior).astype(np.float32)}

    @staticmethod
    def apply(p, X):
        return np.maximum(X @ p["W1"] + p["b1"], 0) @ p["W2"] + p["b2"]

    def logits(self, X):
        return self.apply(self.p, X)

    def fit(self, X, Y, w, epochs, bs, lr, l2, seed=0):
        r, opt, p = np.random.RandomState(seed), Adam(lr), self.p
        n = len(X)
        for _ in range(epochs):
            order = r.permutation(n)
            for s in range(0, n, bs):
                ix = order[s:s + bs]
                x, y, ww = X[ix], Y[ix], w[ix]
                a = x @ p["W1"] + p["b1"]
                h = np.maximum(a, 0)
                P = softmax(h @ p["W2"] + p["b2"])
                d = (P - y) * (ww / ww.sum())[:, None]
                dh = (d @ p["W2"].T) * (a > 0)
                g = {"W2": h.T @ d + 2 * l2 * p["W2"], "b2": d.sum(0), "W1": x.T @ dh + 2 * l2 * p["W1"], "b1": dh.sum(0)}
                opt.step(p, {k: v.astype(np.float32) for k, v in g.items()})
        return self


# ----------------------------------------------------------------------------- solution 1: tuned decayed frequency
def s1_predict(OH, cut, ts, prior_ts, hl, strength):
    age = (cut[:, None] - 1 - np.arange(T)[None, :]).astype(np.float64)
    W = np.where(age >= 0, 0.5 ** (age / hl), 0.0)
    counts = np.einsum("mt,mtc->mc", W, OH.astype(np.float64)) + strength * prior_ts[ts]
    return counts / counts.sum(1, keepdims=True)


def s1_fit(C, trm, cfg):
    ts = C.mtype * 3 + C.sig
    cnt = np.zeros((9, 5))
    for t in range(9):
        cnt[t] = C.OH[trm & (ts == t)].sum((0, 1))
    g = cnt.sum(0) + 0.5
    g /= g.sum()
    prior_ts = (cnt + 12 * g) / (cnt.sum(1, keepdims=True) + 12)
    best = None
    idx = np.nonzero(trm)[0]
    for hl in cfg["s1_hl"]:
        for st in cfg["s1_strength"]:
            P = s1_predict(C.OH[idx], C.cut[idx], ts[idx], prior_ts, hl, st)
            e = ((P - C.qY[idx]) ** 2).sum(1).mean()
            if best is None or e < best[0]:
                best = (e, hl, st)
    return {"prior_ts": prior_ts, "hl": best[1], "strength": best[2]}


# ----------------------------------------------------------------------------- solution 3: per-machine adaptation of S2 logits
def s3_predict(C, sel, base_logits, qbase, cfg):
    """Fit per-machine lag adjustments on its own history (ticks < cutoff), shrunk toward the global model."""
    ex = np.nonzero(np.isin(C.hmi, sel))[0]
    row = np.searchsorted(sel, C.hmi[ex])
    order = np.argsort(row, kind="stable")
    ex, row = ex[order], row[order]
    R = len(sel)
    cnt = np.bincount(row, minlength=R)
    start = np.concatenate([[0], np.cumsum(cnt)[:-1]])
    pos = np.arange(len(ex)) - start[row]
    N = cnt.max()
    sl = LAYOUT["wl"]
    Fx = np.concatenate([np.ones((len(ex), 1), np.float32), C.hX[ex][:, sl]], 1)
    nf = Fx.shape[1]
    Fp = np.zeros((R, N, nf), np.float32)
    Zp = np.zeros((R, N, 5), np.float32)
    Yp = np.zeros((R, N, 5), np.float32)
    Wp = np.zeros((R, N), np.float32)
    Fp[row, pos], Zp[row, pos], Yp[row, pos] = Fx, base_logits(C.hX[ex]), C.hY[ex]
    age = C.cut[sel][row] - 1 - C.hti[ex]
    Wp[row, pos] = 0.5 ** (age / cfg["s3_hl"])
    A = {"A": np.zeros((R, nf, 5), np.float32)}
    reg = np.ones((1, nf, 1), np.float32)
    reg[0, 0] = 0.1
    opt = Adam(cfg["s3_lr"])
    for _ in range(cfg["s3_steps"]):
        P = softmax((Zp + np.einsum("rnf,rfc->rnc", Fp, A["A"])).reshape(-1, 5)).reshape(R, N, 5)
        G = np.einsum("rnf,rnc->rfc", Fp, (P - Yp) * Wp[..., None]) + 2 * cfg["s3_l2"] * reg * A["A"]
        opt.step(A, {"A": G})
    fq = np.concatenate([np.ones((R, 1), np.float32), C.qX[sel][:, sl]], 1)
    return softmax(qbase + np.einsum("rf,rfc->rc", fq, A["A"]))


# ----------------------------------------------------------------------------- fitting / predicting all models
NB_BLOCKS = ("nrate8", "ncov8", "nrate32", "ncov32", "nrate128", "ncov128", "nfrac")


def cols_for(kind):
    keep = [k for k in LAYOUT if kind == "B" or k not in NB_BLOCKS]
    return np.concatenate([np.arange(LAYOUT[k].start, LAYOUT[k].stop) for k in keep])


def _ens_logits(nets, cols, X):
    P = np.mean([softmax(MLP.apply(p, X[:, cols])) for p in nets], 0)
    return np.log(np.clip(P, 1e-9, None))


def fit_models(C, trm, cfg, verbose=False):
    hm = trm[C.hmi]
    X = np.concatenate([C.hX[hm], C.qX[trm]])
    Y = np.concatenate([C.hY[hm], C.qY[trm].astype(np.float32)])
    w = np.concatenate([np.ones(hm.sum(), np.float32), np.where(C.qsoft[trm], cfg["wq"], 1.0).astype(np.float32)])
    mu = X.mean(0)
    sd = X.std(0)
    sd[sd < 1e-6] = 1.0
    Xs = ((X - mu) / sd).astype(np.float32)
    M = {"mu": mu, "sd": sd, "s1": s1_fit(C, trm, cfg), "cfg": cfg, "nets": {}}
    for kind, H, seeds in (("A", cfg["h_a"], cfg["seeds_a"]), ("B", cfg["h_b"], cfg["seeds_b"])):
        cols = cols_for(kind)
        M["nets"][kind] = [MLP(len(cols), H, C.prior, s).fit(Xs[:, cols], Y, w, cfg["mlp_epochs"], cfg["mlp_bs"], cfg["mlp_lr"], cfg["mlp_l2"], s).p
                           for s in seeds]
    return M


def predict_models(M, C, sel):
    """Return {s1..s4: (len(sel),5)} for machines `sel` (sorted ints)."""
    cfg = M["cfg"]
    std = lambda X: ((X - M["mu"]) / M["sd"]).astype(np.float32)
    ts = C.mtype * 3 + C.sig
    Xq = std(C.qX[sel])
    colsA, colsB = cols_for("A"), cols_for("B")
    zA = _ens_logits(M["nets"]["A"], colsA, Xq)
    zB = _ens_logits(M["nets"]["B"], colsB, Xq)
    out = {
        "s1": s1_predict(C.OH[sel], C.cut[sel], ts[sel], M["s1"]["prior_ts"], M["s1"]["hl"], M["s1"]["strength"]),
        "s2": softmax(zA),
        "s3": softmax(zB),
        "s4": s3_predict(C, sel, lambda X: _ens_logits(M["nets"]["A"], colsA, std(X)), zA, cfg),
    }
    return {k: np.clip(v, 1e-6, None) / np.clip(v, 1e-6, None).sum(1, keepdims=True) for k, v in out.items()}


# ----------------------------------------------------------------------------- solution 5: regime gate
def gate_feats(qX):
    L = LAYOUT
    g = [np.ones((len(qX), 1), np.float32), qX[:, L["cov64"]], qX[:, L["cov128"]], (qX[:, L["cov64"]] < 0.9).astype(np.float32),
         qX[:, L["drift"]][:, 2:4], qX[:, L["ncov8"]], qX[:, L["type"]][:, :2]]
    return np.concatenate(g, 1).astype(np.float64)


def fit_gate(P, Y, g, l2=1e-2, iters=400, lr=0.05):
    K = P.shape[0]
    Wg = {"W": np.zeros((g.shape[1], K))}
    opt = Adam(lr)
    for _ in range(iters):
        w = softmax(g @ Wg["W"])
        p = np.einsum("mk,kmc->mc", w, P)
        dw = 2 * np.einsum("mc,kmc->mk", p - Y, P)
        du = w * (dw - (w * dw).sum(1, keepdims=True))
        opt.step(Wg, {"W": g.T @ du / len(g) + 2 * l2 * Wg["W"]})
    return Wg["W"]


def apply_gate(Wg, P, g):
    w = softmax(g @ Wg)
    return np.einsum("mk,kmc->mc", w, P)


# ----------------------------------------------------------------------------- evaluation
def contest(P, C, max_points):
    """Official-style score on a corpus with true targets and pooled reference."""
    ratios, rows = [], {}
    for c in ("stable", "short_history", "drift", "shared_change"):
        ids = np.nonzero(C.cond == c)[0]

        def err(X):
            e = ((X[ids] - C.tgt[ids]) ** 2).sum(1)
            return np.mean([e[C.ep[ids] == u].mean() for u in np.unique(C.ep[ids])])

        e, b = err(P), err(C.ref)
        ratios.append(e / max(b, 1e-9))
        rows[c] = round(ratios[-1], 3)
    R = float(np.mean(ratios))
    return {"points": max_points / (1 + R), "R": R, "by_cond": rows}


DEFAULT_CFG = dict(wq=5.0, h_a=64, h_b=96, seeds_a=(0, 1, 2, 3, 4), seeds_b=(10, 11, 12, 13, 14), mlp_epochs=12, mlp_bs=1024, mlp_lr=2e-3, mlp_l2=1e-5,
                   s3_l2=8.0, s3_steps=80, s3_lr=0.03, s3_hl=64.0, s1_hl=(12, 24, 48, 96, 200, 1e9), s1_strength=(4, 8, 16, 32), seed=0)


# ----------------------------------------------------------------------------- checkpoint I/O
def save_ckpt(path, M, Wg, prior):
    a = {"prior": prior, "mu": M["mu"], "sd": M["sd"], "s1_prior_ts": M["s1"]["prior_ts"],
         "s1_params": np.array([M["s1"]["hl"], M["s1"]["strength"]]), "Wg": Wg}
    for kind, nets in M["nets"].items():
        a[f"n_{kind}"] = np.array(len(nets))
        for i, p in enumerate(nets):
            for k, v in p.items():
                a[f"{kind}{i}_{k}"] = v.astype(np.float64)
    cfg = {k: (list(v) if isinstance(v, tuple) else v) for k, v in M["cfg"].items()}
    a["cfg_json"] = np.frombuffer(json.dumps(cfg).encode(), dtype=np.uint8)
    np.savez_compressed(path, **a)


def load_ckpt(path):
    z = np.load(path, allow_pickle=False)
    cfg = json.loads(bytes(z["cfg_json"]).decode())
    nets = {kind: [{k: z[f"{kind}{i}_{k}"] for k in ("W1", "b1", "W2", "b2")} for i in range(int(z[f"n_{kind}"]))] for kind in ("A", "B")}
    M = {"mu": z["mu"], "sd": z["sd"], "cfg": cfg, "nets": nets,
         "s1": {"prior_ts": z["s1_prior_ts"], "hl": float(z["s1_params"][0]), "strength": float(z["s1_params"][1])}}
    return M, z["Wg"], z["prior"]


# ============================================================================= v1: MLP + gated P(loss) (pair lookups)
GATE_K = 4


def _mlp_probs(Mod, X):
    std = ((X - Mod["mu"]) / Mod["sd"]).astype(X.dtype)
    return np.clip(softmax(_ens_logits(Mod["nets"], cols_for("A"), std)), 1e-9, None)


def _cands(X, pm):
    cur = X[:, LAYOUT["pairs"]][:, :3 * len(PHL)].reshape(-1, PTOP, len(PHL))[:, 0, :]
    hm = X[:, LAYOUT["hmm"]]
    step = 5 * HMM_TOP + 1
    return np.stack([pm[:, 0], cur[:, 0], cur[:, 1], cur[:, 2]] + [hm[:, j * step] for j in range(len(HMM_EPS))], 0)


def _gfeat(X):
    pf = X[:, LAYOUT["pairs"]]
    cur = pf[:, :3 * len(PHL)].reshape(-1, PTOP, len(PHL))[:, 0, :]
    st, sup = pf[:, -PTOP:], pf[:, -2 * PTOP:-PTOP]
    return np.column_stack([np.ones(len(X)), np.abs(cur[:, 0] - cur[:, 2]), np.abs(cur[:, 1] - cur[:, 2]), np.abs(cur[:, 0] - cur[:, 1]),
                            X[:, LAYOUT["flip"]], X[:, LAYOUT["cov64"]], X[:, LAYOUT["cov128"]], st[:, 0], st[:, 0] - st[:, 1], sup[:, 0],
                            X[:, LAYOUT["t"]], X[:, LAYOUT["hmm"]][:, 1:]]).astype(np.float64)


def _fit_mlp(C, trm, cfg):
    hm = trm[C.hmi]
    X = np.concatenate([C.hX[hm], C.qX[trm]])
    Y = np.concatenate([C.hY[hm], C.qY[trm].astype(np.float32)])
    w = np.concatenate([np.ones(hm.sum(), np.float32), np.where(C.qsoft[trm], cfg["wq"], 1.0).astype(np.float32)])
    mu, sd = X.mean(0), X.std(0)
    sd[sd < 1e-6] = 1.0
    Xs = ((X - mu) / sd).astype(np.float32)
    cols = cols_for("A")
    nets = [MLP(len(cols), cfg["h_a"], C.prior, s).fit(Xs[:, cols], Y, w, cfg["mlp_epochs"], cfg["mlp_bs"], cfg["mlp_lr"], cfg["mlp_l2"], s).p
            for s in cfg["seeds_a"]]
    return {"mu": mu, "sd": sd, "nets": nets}


def episode_folds(C, K, seed=0):
    fm = np.zeros(C.M, int)
    r = np.random.RandomState(seed)
    for c in np.unique(C.cond):
        eps = np.unique(C.ep[C.cond == c])
        r.shuffle(eps)
        for i, e in enumerate(eps):
            fm[C.ep == e] = i % K
    return fm


def fit_v1(C, trm, cfg, log=print):
    """Out-of-fold gate (episode folds within trm), then MLP on all of trm."""
    fm = episode_folds(C, GATE_K)
    GX, GP, GY = [], [], []
    for k in range(GATE_K):
        Mk = _fit_mlp(C, trm & (fm != k), cfg)
        hm = trm[C.hmi] & (fm[C.hmi] == k) & (C.hti >= 48)
        qm = trm & (fm == k)
        for X, Y in ((C.hX[hm], C.hY[hm][:, 0]), (C.qX[qm], C.qY[qm][:, 0])):
            pm = _mlp_probs(Mk, X)
            GX.append(_gfeat(X)); GP.append(_cands(X, pm)); GY.append(Y)
        log(f"  gate fold {k} done")
    GX, GP, GY = np.concatenate(GX), np.concatenate(GP, 1), np.concatenate(GY)
    gmu, gsd = GX.mean(0), GX.std(0)
    gsd[gsd < 1e-6] = 1.0
    gmu[0], gsd[0] = 0.0, 1.0
    W = fit_gate(np.stack([GP, 1 - GP], 2), np.stack([GY, 1 - GY], 1), (GX - gmu) / gsd, l2=1e-3, iters=600)
    Mod = _fit_mlp(C, trm, cfg)
    Mod.update(gW=W, gmu=gmu, gsd=gsd)
    return Mod


def predict_v1(Mod, X, gated=True):
    pm = _mlp_probs(Mod, X)
    if not gated:
        return pm / pm.sum(1, keepdims=True)
    w = softmax(((_gfeat(X) - Mod["gmu"]) / Mod["gsd"]) @ Mod["gW"])
    L = np.clip((w * _cands(X, pm).T).sum(1), 1e-4, 1 - 1e-4)
    rest = pm[:, 1:] / pm[:, 1:].sum(1, keepdims=True)
    return np.column_stack([L, (1 - L)[:, None] * rest])


def save_v1(path, Mod, prior, cfg):
    a = {"prior": np.asarray(prior, np.float64), "mu": Mod["mu"], "sd": Mod["sd"], "gW": Mod["gW"], "gmu": Mod["gmu"], "gsd": Mod["gsd"],
         "n_nets": np.array(len(Mod["nets"]))}
    for i, p in enumerate(Mod["nets"]):
        for k, v in p.items():
            a[f"A{i}_{k}"] = v.astype(np.float64)
    c = {k: (list(v) if isinstance(v, tuple) else v) for k, v in cfg.items()}
    a["cfg_json"] = np.frombuffer(json.dumps(c).encode(), dtype=np.uint8)
    np.savez_compressed(path, **a)


def load_v1(path):
    z = np.load(path, allow_pickle=False)
    nets = [{k: z[f"A{i}_{k}"].astype(np.float32) for k in ("W1", "b1", "W2", "b2")} for i in range(int(z["n_nets"]))]
    Mod = {"mu": z["mu"], "sd": z["sd"], "gW": z["gW"], "gmu": z["gmu"], "gsd": z["gsd"], "nets": nets}
    return Mod, z["prior"], json.loads(bytes(z["cfg_json"]).decode())


V1_CFG = dict(DEFAULT_CFG, seeds_b=())
