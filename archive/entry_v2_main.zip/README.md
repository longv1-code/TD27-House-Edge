# House Edge entry (main round, v2 gated)

- Environment: python image, numpy==2.4.4 (see requirements.txt). No network, no other packages. Tested on Python 3.14.0 and 3.12.3.
- Recreate: python predict.py --data /data --out /output/submission.csv --solution gated
- The command loads model.npz (trained weights, seeds fixed in the config stored inside it) and runs a deterministic float64 forward pass on /data/test (float64 so BLAS-kernel and platform rounding differences stay near 1e-15). Runtime under 1 minute on 2 cores, under 2 GiB RAM.
- Model: per (machine, tick) features from ticks strictly before the target tick: lagged payouts, windowed rates, per-machine lag tables, per-machine XOR lag-pair cell rates (all 28 pairs of lags 1-8, several memory lengths), and a two-state switching filter per lag pair (causal forward pass, pair chosen by running log-likelihood). A 5-seed MLP ensemble predicts the full distribution; a gate fitted out-of-fold mixes its P(loss) with the pair-lookup and filter estimates, and the non-loss mass keeps the MLP's split.
- Training (not needed for reproduction): python fit_final.py --data public --ckpt model.npz (train+validation). Honest check: python dev.py --data public (train only, scored on validation).
- No outside data.
