"""Deterministic forward pass from a saved checkpoint.
python predict.py --data /data --out /output/submission.csv [--solution gated|mlp] [--ckpt model.npz]"""
import argparse, csv
from pathlib import Path
import numpy as np
import he

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--out", required=True)
ap.add_argument("--solution", default="gated", choices=["gated", "mlp"])
ap.add_argument("--ckpt", default=str(Path(__file__).resolve().parent / "model.npz"))
a = ap.parse_args()
he.FEAT_DTYPE = np.float64  # float64 forward pass: reproducible across platforms/BLAS kernels
Mod, prior, cfg = he.load_v1(a.ckpt)
Mod["nets"] = [{k: v.astype(np.float64) for k, v in p.items()} for p in Mod["nets"]]
S = he.Split(Path(a.data) / "test")
C = he.Corpus([S], prior)
out = he.predict_v1(Mod, C.qX, gated=(a.solution == "gated"))
out = np.clip(out, 1e-6, None)
out = out / out.sum(1, keepdims=True)
Path(a.out).parent.mkdir(parents=True, exist_ok=True)
with open(a.out, "w", encoding="utf-8", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["query_id", "p_0", "p_1", "p_2", "p_5", "p_20"])
    for i in np.argsort(C.qid):
        w.writerow([C.qid[i]] + [format(float(x), ".17g") for x in out[i]])
