"""Fit the v1 model on <data>/train + <data>/validation and write a checkpoint.
Usage: python fit_final.py --data public --ckpt model.npz [--no-val] [--extra OTHER_PUBLIC]"""
import argparse, time
import numpy as np
import he

ap = argparse.ArgumentParser()
ap.add_argument("--data", default="public")
ap.add_argument("--ckpt", default="model.npz")
ap.add_argument("--no-val", action="store_true")
ap.add_argument("--extra", default=None, help="another round's public folder (train+validation added to training)")
a = ap.parse_args()
t0 = time.time()
splits = [he.Split(f"{a.data}/train")] + ([] if a.no_val else [he.Split(f"{a.data}/validation")])
if a.extra:
    splits += [he.Split(f"{a.extra}/train"), he.Split(f"{a.extra}/validation")]
prior = he.global_prior(splits)
C = he.Corpus(splits, prior)
print(f"features ready {time.time()-t0:.0f}s  ex={len(C.hX)}", flush=True)
Mod = he.fit_v1(C, np.ones(C.M, bool), he.V1_CFG, log=lambda s: print(s, f"{time.time()-t0:.0f}s", flush=True))
he.save_v1(a.ckpt, Mod, prior, he.V1_CFG)
print(f"saved {a.ckpt}  total {time.time()-t0:.0f}s")
